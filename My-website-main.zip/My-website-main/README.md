Hello guys!!!
This project is done in HTML and CSS. 
I wanted to create a personal website to practice my HTML and CSS skills. 
The source code is open so feel free to use it. 
.
.
.

Thank you danidev.net (https://www.youtube.com/c/DaniDev). As the website is heavily inspired from his site..

